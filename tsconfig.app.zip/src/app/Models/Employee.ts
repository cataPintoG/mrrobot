export interface Employee
{
    id : number;
    name : string;
    salary: number;
    annualSalary : number;
    age : number;
}