export const appsettings = {
    apiUrl : "https://localhost:7247/api/v1/"
}